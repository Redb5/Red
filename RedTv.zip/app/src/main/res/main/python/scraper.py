import requests
from bs4 import BeautifulSoup

def fetch_matches():
    url = "https://www.livesoccertv.com/"
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    }
    
    response = requests.get(url, headers=headers)
    if response.status_code != 200:
        return []

    soup = BeautifulSoup(response.content, 'html.parser')
    matches = []

    for match in soup.select("tr.matchrow"):
        team_names = match.select_one("a.topmatch")
        match_time = match.select_one("span.ts")
        channels = [ch.text.strip() for ch in match.select("td#channels a")]

        match_info = {
            "team": team_names.text.strip() if team_names else "Not available",
            "time": match_time.text.strip() if match_time else "Not available",
            "channels": ", ".join(channels) if channels else "Not available"
        }
        matches.append(match_info)

    return matches