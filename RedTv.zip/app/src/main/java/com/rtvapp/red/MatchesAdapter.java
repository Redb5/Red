package com.rtvapp.red;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URLEncoder;
import java.net.URL;
import java.util.List;
import java.util.UUID;
import org.json.JSONException;
import org.json.JSONObject;

public class MatchesAdapter extends RecyclerView.Adapter<MatchesAdapter.MatchViewHolder> {
    private List<Match> matches;
    private Context context;
    private String apiKey = "3a7d8f1e4c9b2a5d6e8f0a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1";
    private String hmacSecret = "5ffc36387eaaf6a8ae23f2edc74683c619ac50c9d67654da0fcde0907a061167";

    public MatchesAdapter(Context context, List<Match> matches) {
        this.context = context;
        this.matches = matches;
    }

    @NonNull
    @Override
    public MatchViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_match, parent, false);
        return new MatchViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MatchViewHolder holder, int position) {
        Match match = matches.get(position);

        // تعيين البيانات الأساسية
        holder.homeTeam.setText(match.getHomeTeam());
        holder.awayTeam.setText(match.getAwayTeam());
        holder.tournamentName.setText(match.getLeague());
        holder.matchTime.setText(match.getMatchTime());
        holder.score.setText(match.getScore());
        holder.matchStatus.setText(match.getStatus());
        holder.channels.setText(match.getChannels());

        // تعيين بيانات الهدافين
        holder.homeScorers.setText(match.getFormattedHomeScorers());
        holder.awayScorers.setText(match.getFormattedAwayScorers());

        // تحميل شعارات الفرق
        Glide.with(context)
                .load(match.getHomeLogo())
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .placeholder(R.drawable.default_image)
                .error(R.drawable.default_image)
                .into(holder.homeLogo);

        Glide.with(context)
                .load(match.getAwayLogo())
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .placeholder(R.drawable.default_image)
                .error(R.drawable.default_image)
                .into(holder.awayLogo);

        // إضافة مستمع للنقر على العنصر
        holder.container.setOnClickListener(v -> {
            String channelName = match.getChannels();
            if (channelName != null && !channelName.isEmpty() && !channelName.equalsIgnoreCase("No channels")) {
                new FetchStreamUrlTask(context, channelName, apiKey, hmacSecret).execute();
            } else {
                Toast.makeText(context, "لا توجد قنوات متاحة لهذه المباراة", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return matches.size();
    }

    public void updateMatches(List<Match> newMatches) {
        matches.clear();
        matches.addAll(newMatches);
        notifyDataSetChanged();
    }

    static class MatchViewHolder extends RecyclerView.ViewHolder {
        CardView container;
        TextView homeTeam, awayTeam, tournamentName, matchTime, score, matchStatus, channels;
        TextView homeScorers, awayScorers;
        ImageView homeLogo, awayLogo;

        public MatchViewHolder(@NonNull View itemView) {
            super(itemView);
            container = itemView.findViewById(R.id.container);
            homeTeam = itemView.findViewById(R.id.homeTeam);
            awayTeam = itemView.findViewById(R.id.awayTeam);
            tournamentName = itemView.findViewById(R.id.tournamentName);
            matchTime = itemView.findViewById(R.id.matchTime);
            score = itemView.findViewById(R.id.score);
            matchStatus = itemView.findViewById(R.id.matchStatus);
            channels = itemView.findViewById(R.id.channels);
            homeScorers = itemView.findViewById(R.id.homeScorers);
            awayScorers = itemView.findViewById(R.id.awayScorers);
            homeLogo = itemView.findViewById(R.id.homeLogo);
            awayLogo = itemView.findViewById(R.id.awayLogo);
        }
    }

    private static class FetchStreamUrlTask extends AsyncTask<Void, Void, String> {
        private Context context;
        private String channelName;
        private String apiKey;
        private String hmacSecret;

        public FetchStreamUrlTask(Context context, String channelName, String apiKey, String hmacSecret) {
            this.context = context;
            this.channelName = channelName;
            this.apiKey = apiKey;
            this.hmacSecret = hmacSecret;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            Toast.makeText(context, "جاري التحميل...", Toast.LENGTH_SHORT).show();
        }

        @Override
        protected String doInBackground(Void... voids) {
            try {
                String encodedChannelName = URLEncoder.encode(channelName.replace(" ", "-"), "UTF-8");
                String url = "https://crimson-sky-a303.rahoumc07.workers.dev/get-channel-url?channel=" + encodedChannelName;
                String timestamp = String.valueOf(System.currentTimeMillis());
                String nonce = UUID.randomUUID().toString();
                String dataToSign = timestamp + nonce + "/get-channel-url?channel=" + encodedChannelName;
                String signature = generateHMACSignature(dataToSign, hmacSecret);
                HttpURLConnection connection = (HttpURLConnection) new URL(url).openConnection();
                connection.setRequestMethod("GET");
                connection.setRequestProperty("X-API-KEY", apiKey);
                connection.setRequestProperty("X-TIMESTAMP", timestamp);
                connection.setRequestProperty("X-NONCE", nonce);
                connection.setRequestProperty("X-SIGNATURE", signature);
                connection.setConnectTimeout(15000);
                connection.setReadTimeout(15000);
                int responseCode = connection.getResponseCode();
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                    StringBuilder response = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }
                    reader.close();
                    return response.toString();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(String jsonResponse) {
            if (jsonResponse != null && !jsonResponse.isEmpty()) {
                try {
                    JSONObject jsonObject = new JSONObject(jsonResponse);
                    String streamUrl = jsonObject.getString("url");
                    if (streamUrl != null && !streamUrl.isEmpty()) {
                        openStreamInPlayerActivity(streamUrl);
                    } else {
                        Toast.makeText(context, "رابط البث غير صالح", Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    Toast.makeText(context, "خطأ في معالجة البيانات", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(context, "فشل في الحصول على رابط البث", Toast.LENGTH_SHORT).show();
            }
        }

        private void openStreamInPlayerActivity(String streamUrl) {
            Intent intent = new Intent(context, PlayerActivity.class);
            intent.putExtra("mode", true);
            intent.putExtra("data", streamUrl);
            context.startActivity(intent);
        }

        private String generateHMACSignature(String data, String secretKey) {
            try {
                javax.crypto.Mac mac = javax.crypto.Mac.getInstance("HmacSHA256");
                mac.init(new javax.crypto.spec.SecretKeySpec(secretKey.getBytes(java.nio.charset.StandardCharsets.UTF_8), "HmacSHA256"));
                byte[] signatureBytes = mac.doFinal(data.getBytes(java.nio.charset.StandardCharsets.UTF_8));
                StringBuilder result = new StringBuilder();
                for (byte b : signatureBytes) {
                    result.append(String.format("%02x", b));
                }
                return result.toString();
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }
    }
}