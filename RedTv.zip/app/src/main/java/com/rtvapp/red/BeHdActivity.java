package com.rtvapp.red;


import java.lang.reflect.Field;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets; // اختياري (للطريقة الثانية)
import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.webkit.*;
import android.widget.*;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import com.android.volley.*;
import com.android.volley.toolbox.*;
import com.bumptech.glide.*;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.card.MaterialCardView;
import com.google.firebase.*;
import com.google.firebase.database.*;
import java.io.*;
import java.net.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import org.json.*;

public class BeHdActivity extends AppCompatActivity {
    private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
    private Toolbar _toolbar;
    private AppBarLayout _app_bar;
    private CoordinatorLayout _coordinator;
    private HashMap<String, Object> grid1 = new HashMap<>();
    private String chain1 = "";
    private ArrayList<HashMap<String, Object>> channels_list = new ArrayList<>();
    private SharedPreferences sharedPreferences;
    private String apiKey = "3a7d8f1e4c9b2a5d6e8f0a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1";
    private String hmacSecret = "5ffc36387eaaf6a8ae23f2edc74683c619ac50c9d67654da0fcde0907a061167";
    private LinearLayout linear1;
    private GridView gridview1;
    private LinearLayout linear2;
    private AlertDialog.Builder no_internet;
    private RequestNetwork wifi;
    private RequestNetwork.RequestListener _wifi_request_listener;
    private DatabaseReference Db = _firebase.getReference("Db");
    private ChildEventListener _Db_child_listener;
    private RequestQueue requestQueue;

    @Override
    protected void onCreate(Bundle _savedInstanceState) {
        super.onCreate(_savedInstanceState);
        setContentView(R.layout.be_fhd);
        initialize(_savedInstanceState);
        FirebaseApp.initializeApp(this);
        sharedPreferences = getSharedPreferences("ChannelImages", MODE_PRIVATE);
        requestQueue = Volley.newRequestQueue(this);
        initializeLogic();
    }

    private void initialize(Bundle _savedInstanceState) {
        _app_bar = findViewById(R.id._app_bar);
        _coordinator = findViewById(R.id._coordinator);
        _toolbar = findViewById(R.id._toolbar);
        setSupportActionBar(_toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        _toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View _v) {
                onBackPressed();
            }
        });
        linear1 = findViewById(R.id.linear1);
        gridview1 = findViewById(R.id.gridview1);
        linear2 = findViewById(R.id.linear2);
        no_internet = new AlertDialog.Builder(this);
        wifi = new RequestNetwork(this);
        gridview1.setOnItemClickListener(null);
        _wifi_request_listener = new RequestNetwork.RequestListener() {
            @Override
            public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
                final String _tag = _param1;
                final String _response = _param2;
                final HashMap<String, Object> _responseHeaders = _param3;
            }

            @Override
            public void onErrorResponse(String _param1, String _param2) {
                final String _tag = _param1;
                final String _message = _param2;
                no_internet.setTitle("Connection Error");
                no_internet.setMessage("You are not connected to the internet. Please check your connection and try again.");
                no_internet.setIcon(R.drawable.no_internet);
                no_internet.setPositiveButton("Reload", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface _dialog, int _which) {
                        finish();
                        startActivity(getIntent());
                    }
                });
                no_internet.setCancelable(false);
                no_internet.create().show();
            }
        };
        _Db_child_listener = new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot _param1, String _param2) {
                GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
                final String _childKey = _param1.getKey();
                final HashMap<String, Object> _childValue = _param1.getValue(_ind);
            }

            @Override
            public void onChildChanged(DataSnapshot _param1, String _param2) {
                GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
                final String _childKey = _param1.getKey();
                final HashMap<String, Object> _childValue = _param1.getValue(_ind);
            }

            @Override
            public void onChildMoved(DataSnapshot _param1, String _param2) {}

            @Override
            public void onChildRemoved(DataSnapshot _param1) {
                GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
                final String _childKey = _param1.getKey();
                final HashMap<String, Object> _childValue = _param1.getValue(_ind);
            }

            @Override
            public void onCancelled(DatabaseError _param1) {
                final int _errorCode = _param1.getCode();
                final String _errorMessage = _param1.getMessage();
            }
        };
        Db.addChildEventListener(_Db_child_listener);
    }

    private void initializeLogic() {
        _navigationBarColor();
        _getValue();
        _addChannelToList();
        _hideVerticalScrollBarGrid();
        gridview1.setAdapter(new Gridview1Adapter(channels_list));
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuItem menuItem = menu.add(Menu.NONE, 0, Menu.NONE, "search");
        menuItem.setIcon(R.drawable.ic_search);
        menuItem.setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        final int _id = item.getItemId();
        final String _title = (String) item.getTitle();
        if (item.getItemId() == 0) {
            SearchView searchView = new SearchView(this);
            searchView.setQueryHint("search for...");
            searchView.setIconifiedByDefault(false);
            
            // تغيير لون نص البحث والنص الإرشادي إلى الأبيض
            try {
                // الحصول على الـ EditText داخل SearchView
                int searchPlateId = searchView.getContext().getResources().getIdentifier("android:id/search_src_text", null, null);
                EditText searchEditText = searchView.findViewById(searchPlateId);
                
                if (searchEditText != null) {
                    searchEditText.setTextColor(Color.WHITE); // لون النص المكتوب
                    searchEditText.setHintTextColor(Color.parseColor("#80FFFFFF")); // لون النص الإرشادي (أبيض شفاف)
                    
                    
                    // تغيير لون المؤشر (الكرسور) إلى الأبيض
                    try {
                        Field cursorDrawableResField = TextView.class.getDeclaredField("mCursorDrawableRes");
                        cursorDrawableResField.setAccessible(true);
                        cursorDrawableResField.set(searchEditText, R.drawable.white_cursor);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                
                // تغيير لون أيقونة البحث والإغلاق إذا لزم الأمر
                int searchIconId = getResources().getIdentifier("android:id/search_mag_icon", null, null);
                ImageView searchIcon = searchView.findViewById(searchIconId);
                if (searchIcon != null) {
                    searchIcon.setColorFilter(Color.WHITE);
                }
                
                int closeButtonId = getResources().getIdentifier("android:id/search_close_btn", null, null);
                ImageView closeButton = searchView.findViewById(closeButtonId);
                if (closeButton != null) {
                    closeButton.setColorFilter(Color.WHITE);
                }
                
            } catch (Exception e) {
                e.printStackTrace();
            }
            
            searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
                @Override
                public boolean onQueryTextSubmit(String query) {
                    Toast.makeText(BeHdActivity.this, "بحث عن: " + query, Toast.LENGTH_SHORT).show();
                    return true;
                }

                @Override
                public boolean onQueryTextChange(String newText) {
                    ((Gridview1Adapter) gridview1.getAdapter()).getFilter().filter(newText);
                    return false;
                }
            });
            item.setActionView(searchView);
            item.expandActionView();
        }
        return super.onOptionsItemSelected(item);
    }

    public void _hideVerticalScrollBarGrid() {
        GridView gridView = findViewById(R.id.gridview1);
        gridView.setVerticalScrollBarEnabled(false);
        gridView.setHorizontalScrollBarEnabled(false);
    }

    public void _navigationBarColor() {
        getWindow().setNavigationBarColor(Color.parseColor("#5580A0"));
    }

    public void _addChannelToList() {
        String[] keys = getIntent().getStringArrayExtra("keys");
        if (keys != null) {
            for (String channel : keys) {
                HashMap<String, Object> _item = new HashMap<>();
                _item.put("key", channel);
                channels_list.add(_item);
            }
        }
    }

    public void _getValue() {
        grid1 = new HashMap<>();
        Db.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot _dataSnapshot) {
                if (_dataSnapshot.child("beIN fhd").exists()) {
                    for (DataSnapshot tvData : _dataSnapshot.child("beIN fhd").getChildren()) {
                        String key = tvData.getKey();
                        Object value = tvData.getValue();
                        grid1.put(key, value);
                    }
                }
                grid1.put("test", "test");
            }

            @Override
            public void onCancelled(DatabaseError _databaseError) {}
        });
    }

    private void fetchStreamUrl(String channelName) {
        final ProgressDialog progressDialog = new ProgressDialog(BeHdActivity.this);
        progressDialog.setMessage("جاري التحميل...");
        progressDialog.setCancelable(false);
        progressDialog.show();

        String encodedChannelName = null;
        try {
            encodedChannelName = URLEncoder.encode(channelName.replace(" ", "-"), "UTF-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }

        String url = "https://crimson-sky-a303.rahoumc07.workers.dev/get-channel-url?channel=" + encodedChannelName;
        String timestamp = String.valueOf(System.currentTimeMillis());
        String nonce = UUID.randomUUID().toString();
        String dataToSign = timestamp + nonce + "/get-channel-url?channel=" + encodedChannelName;
        String signature = generateHMACSignature(dataToSign, hmacSecret);

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
            new Response.Listener<JSONObject>() {
                @Override
                public void onResponse(JSONObject response) {
                    progressDialog.dismiss();
                    try {
                        String streamUrl = response.getString("url");
                        if (streamUrl != null && !streamUrl.isEmpty() &&
                            (streamUrl.startsWith("http://") || streamUrl.startsWith("https://"))) {
                            openStreamInPlayerActivity(streamUrl);
                        } else {
                            Toast.makeText(BeHdActivity.this, "رابط البث غير صالح", Toast.LENGTH_SHORT).show();
                        }
                    } catch (JSONException e) {
                        Toast.makeText(BeHdActivity.this, "خطأ في معالجة البيانات: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                        Log.e("JSONError", "Error parsing JSON", e);
                    }
                }
            },
            new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    progressDialog.dismiss();
                    Toast.makeText(BeHdActivity.this, "خطأ في الاتصال بالخادم: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                    Log.e("VolleyError", "Error fetching stream URL", error);
                }
            }) {
            @Override
            public Map<String, String> getHeaders() {
                HashMap<String, String> headers = new HashMap<>();
                headers.put("X-API-KEY", apiKey);
                headers.put("X-TIMESTAMP", timestamp);
                headers.put("X-NONCE", nonce);
                headers.put("X-SIGNATURE", signature);
                return headers;
            }
        };

        requestQueue.add(request);
    }

    private void openStreamInPlayerActivity(String streamUrl) {
        try {
            if (streamUrl == null || streamUrl.isEmpty()) {
                Toast.makeText(this, "رابط البث غير صالح", Toast.LENGTH_SHORT).show();
                return;
            }
            Intent intent = new Intent(this, PlayerActivity.class);
            intent.putExtra("mode", true);
            intent.putExtra("data", streamUrl);
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "خطأ في فتح المشغل: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            Log.e("PlayerError", "Error opening player", e);
        }
    }

    private String generateHMACSignature(String data, String secretKey) {
        try {
            javax.crypto.Mac mac = javax.crypto.Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(secretKey.getBytes(StandardCharsets.UTF_8), "HmacSHA256"));
            byte[] signatureBytes = mac.doFinal(data.getBytes(java.nio.charset.StandardCharsets.UTF_8));
            StringBuilder result = new StringBuilder();
            for (byte b : signatureBytes) {
                result.append(String.format("%02x", b));
            }
            return result.toString();
        } catch (Exception e) {
            Log.e("HMACError", "Error generating HMAC signature", e);
            return null;
        }
    }

    public class Gridview1Adapter extends BaseAdapter implements Filterable {
        ArrayList<HashMap<String, Object>> _originalList;
        ArrayList<HashMap<String, Object>> _filteredList;

        public Gridview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
            _originalList = new ArrayList<>(_arr);
            _filteredList = new ArrayList<>(_arr);
        }

        @Override
        public int getCount() {
            return _filteredList.size();
        }

        @Override
        public HashMap<String, Object> getItem(int _index) {
            return _filteredList.get(_index);
        }

        @Override
        public long getItemId(int _index) {
            return _index;
        }

        @Override
        public View getView(final int _position, View _v, ViewGroup _container) {
            LayoutInflater _inflater = getLayoutInflater();
            View _view = _v;
            if (_view == null) {
                _view = _inflater.inflate(R.layout.grid_cu, null);
            }

            final MaterialCardView cardview1 = _view.findViewById(R.id.cardview1);
            final LinearLayout linear3 = _view.findViewById(R.id.inner_linear3);
            final ImageView imageview1 = _view.findViewById(R.id.imageview1);
            final TextView textview1 = _view.findViewById(R.id.textview1);

            textview1.setText(_filteredList.get(_position).get("key").toString());
            String channelName = _filteredList.get(_position).get("key").toString();
            String imageUrl = getIntent().getStringExtra(channelName);
            if (imageUrl != null && !imageUrl.isEmpty()) {
                Glide.with(getApplicationContext())
                     .load(imageUrl)
                     .placeholder(R.drawable.loading)
                     .error(R.drawable.placehold)
                     .into(imageview1);
            } else {
                imageview1.setImageResource(R.drawable.placehold);
            }

            textview1.setTypeface(Typeface.createFromAsset(getAssets(), "fonts/opensans_bold.ttf"), 0);

            cardview1.setOnClickListener(v -> {
                String clickedChannelName = _filteredList.get(_position).get("key").toString();
                fetchStreamUrl(clickedChannelName);
            });

            linear3.setClickable(false);
            imageview1.setClickable(false);
            textview1.setClickable(false);

            return _view;
        }

        @Override
        public Filter getFilter() {
            return new Filter() {
                @Override
                protected FilterResults performFiltering(CharSequence constraint) {
                    FilterResults results = new FilterResults();
                    ArrayList<HashMap<String, Object>> filteredList = new ArrayList<>();
                    if (constraint == null || constraint.length() == 0) {
                        filteredList.addAll(_originalList);
                    } else {
                        String filterPattern = constraint.toString().toLowerCase().trim();
                        for (HashMap<String, Object> item : _originalList) {
                            if (item.get("key").toString().toLowerCase().contains(filterPattern)) {
                                filteredList.add(item);
                            }
                        }
                    }
                    results.values = filteredList;
                    results.count = filteredList.size();
                    return results;
                }

                @Override
                protected void publishResults(CharSequence constraint, FilterResults results) {
                    _filteredList.clear();
                    _filteredList.addAll((ArrayList<HashMap<String, Object>>) results.values);
                    notifyDataSetChanged();
                }
            };
        }
    }
}