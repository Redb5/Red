package com.rtvapp.red;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.Intent;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.*;
import androidx.customview.*;
import androidx.customview.poolingcontainer.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.media.*;
import androidx.media3.exoplayer.*;
import androidx.media3.exoplayer.dash.*;
import androidx.media3.ui.*;
import androidx.recyclerview.*;
import androidx.recyclerview.widget.*;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import com.android.volley.*;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.Volley;
import com.android.volley.toolbox.JsonObjectRequest;
import com.bumptech.glide.Glide;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.RequestConfiguration;
import com.google.android.material.*;
import com.google.firebase.FirebaseApp;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

public class HomeFragmentActivity extends Fragment {
    private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
    private HashMap<String, Object> grid1 = new HashMap<>();
    private ArrayList<HashMap<String, Object>> category_list = new ArrayList<>();
    private RecyclerView recyclerview1;
    private Intent i1 = new Intent();
    private DatabaseReference Db = _firebase.getReference("Db");
    private ChildEventListener _Db_child_listener;
    private Intent i2 = new Intent();
    private Intent i3 = new Intent();
    private RequestQueue requestQueue;
    
    private HashMap<String, String[]> channelsCache = new HashMap<>();
    
    // مفاتيح المصادقة
    private static final String HMAC_SECRET = "5ffc36387eaaf6a8ae23f2edc74683c619ac50c9d67654da0fcde0907a061167";
    private static final String API_KEY = "3a7d8f1e4c9b2a5d6e8f0a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1";

    @NonNull
    @Override
    public View onCreateView(@NonNull LayoutInflater _inflater, @Nullable ViewGroup _container, @Nullable Bundle _savedInstanceState) {
        View _view = _inflater.inflate(R.layout.home_fragment, _container, false);
        initialize(_savedInstanceState, _view);
        FirebaseApp.initializeApp(getContext());
        requestQueue = Volley.newRequestQueue(getContext());
        initializeLogic();
        return _view;
    }

    private void initialize(Bundle _savedInstanceState, View _view) {
        recyclerview1 = _view.findViewById(R.id.recyclerview1);
        _Db_child_listener = new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot _param1, String _param2) {
                GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
                final String _childKey = _param1.getKey();
                final HashMap<String, Object> _childValue = _param1.getValue(_ind);
            }

            @Override
            public void onChildChanged(DataSnapshot _param1, String _param2) {
                GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
                final String _childKey = _param1.getKey();
                final HashMap<String, Object> _childValue = _param1.getValue(_ind);
            }

            @Override
            public void onChildMoved(DataSnapshot _param1, String _param2) {
            }

            @Override
            public void onChildRemoved(DataSnapshot _param1) {
                GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
                final String _childKey = _param1.getKey();
                final HashMap<String, Object> _childValue = _param1.getValue(_ind);
            }

            @Override
            public void onCancelled(DatabaseError _param1) {
                final int _errorCode = _param1.getCode();
                final String _errorMessage = _param1.getMessage();
            }
        };
        Db.addChildEventListener(_Db_child_listener);
    }

    private void initializeLogic() {
        _addChannelToList();
        recyclerview1.setAdapter(new Recyclerview1Adapter(category_list));
        recyclerview1.setLayoutManager(new LinearLayoutManager(getContext()));
        fetchAllChannels();
        fetchIcons();
    }

    public void _addChannelToList() {
        {
            HashMap<String, Object> _item = new HashMap<>();
            _item.put("key", "beIN Sports (fhd)");
            category_list.add(_item);
        }
        {
            HashMap<String, Object> _item = new HashMap<>();
            _item.put("key", "beIN Sports (hd)");
            category_list.add(_item);
        }
        {
            HashMap<String, Object> _item = new HashMap<>();
            _item.put("key", "beIN Sports (sd)");
            category_list.add(_item);
        }
        {
            HashMap<String, Object> _item = new HashMap<>();
            _item.put("key", "SSC Channels");
            category_list.add(_item);
        }
        {
            HashMap<String, Object> _item = new HashMap<>();
            _item.put("key", "Other Channels");
            category_list.add(_item);
        }
    }
    
    private void fetchAllChannels() {
        _bnfhdPutExtraKey();
        _bnhdPutExtraKey();
        _bnsdPutExtraKey();
        _sscPutExtraKey();
        _otherPutExtra();
    }
    
    private void fetchIcons() {
        String workerUrl = "https://evrtv.rahoumc07.workers.dev/api/db?endpoint=icon";
        
        String timestamp = String.valueOf(System.currentTimeMillis() / 1000);
        String nonce = generateNonce();
        String signature = generateHmacSignature(timestamp, nonce, "/api/db?endpoint=icon");
        
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, workerUrl, null,
            new Response.Listener<JSONObject>() {
                @Override
                public void onResponse(JSONObject response) {
                    try {
                        Iterator<String> keys = response.keys();
                        while (keys.hasNext()) {
                            String key = keys.next();
                            String value = response.getString(key);
                            grid1.put(key, value);
                        }
                        if (recyclerview1.getAdapter() != null) {
                            recyclerview1.getAdapter().notifyDataSetChanged();
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Log.e("CloudflareError", "Error fetching icons: " + error.getMessage());
                }
            }
        ) {
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> headers = new HashMap<>();
                headers.put("X-API-KEY", API_KEY);
                headers.put("X-TIMESTAMP", timestamp);
                headers.put("X-NONCE", nonce);
                headers.put("X-SIGNATURE", signature);
                return headers;
            }
        };
        requestQueue.add(jsonObjectRequest);
    }

    public void _bnfhdPutExtraKey() {
        fetchChannelsToCache("https://evrtv.rahoumc07.workers.dev/api/db?endpoint=beINfhd_channels", "beINfhd");
    }

    public void _bnhdPutExtraKey() {
        fetchChannelsToCache("https://evrtv.rahoumc07.workers.dev/api/db?endpoint=beINhd_channels.json", "beINhd");
    }

    public void _bnsdPutExtraKey() {
        fetchChannelsToCache("https://evrtv.rahoumc07.workers.dev/api/db?endpoint=beINsd_channels.json", "beINsd");
    }

    public void _sscPutExtraKey() {
        fetchChannelsToCache("https://evrtv.rahoumc07.workers.dev/api/db?endpoint=ssc_channels.json", "ssc");
    }

    public void _otherPutExtra() {
        fetchChannelsToCache("https://evrtv.rahoumc07.workers.dev/api/db?endpoint=other_channels.json", "other");
    }
    
    private void fetchChannelsToCache(String workerUrl, final String cacheKey) {
        String timestamp = String.valueOf(System.currentTimeMillis() / 1000);
        String nonce = generateNonce();
        String path = workerUrl.substring(workerUrl.indexOf("/api"));
        String signature = generateHmacSignature(timestamp, nonce, path);
        
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(
            Request.Method.GET, workerUrl, null,
            new Response.Listener<JSONObject>() {
                @Override
                public void onResponse(JSONObject response) {
                    try {
                        Type type = new TypeToken<Map<String, String>>() {}.getType();
                        Map<String, String> channelMap = new Gson().fromJson(response.toString(), type);
                        List<String> channelList = new ArrayList<>(channelMap.values());
                        String[] keys = channelList.toArray(new String[0]);
                        channelsCache.put(cacheKey, keys);
                    } catch (Exception e) {
                        Log.e("CloudflareError", "Parsing Error: " + e.getMessage());
                    }
                }
            },
            new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Log.e("CloudflareError", "Request Failed: " + error.getMessage());
                }
            }
        ) {
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> headers = new HashMap<>();
                headers.put("X-API-KEY", API_KEY);
                headers.put("X-TIMESTAMP", timestamp);
                headers.put("X-NONCE", nonce);
                headers.put("X-SIGNATURE", signature);
                return headers;
            }
        };
        requestQueue.add(jsonObjectRequest);
    }
    
    private void openCachedActivity(String cacheKey, Class<?> activityClass) {
        if (channelsCache.containsKey(cacheKey)) {
            String[] keys = channelsCache.get(cacheKey);
            Intent intent = new Intent(getContext(), activityClass);
            for (String key : keys) {
                if (grid1.containsKey(key)) {
                    intent.putExtra(key, String.valueOf(grid1.get(key)));
                }
            }
            intent.putExtra("keys", keys);
            startActivity(intent);
        } else {
            switch (cacheKey) {
                case "beINfhd":
                    fetchChannelsFromWorker("https://evrtv.rahoumc07.workers.dev/api/db?endpoint=beINfhd_channels", BeFhdActivity.class);
                    break;
                case "beINhd":
                    fetchChannelsFromWorker("https://evrtv.rahoumc07.workers.dev/api/db?endpoint=beINhd_channels", BeHdActivity.class);
                    break;
                case "beINsd":
                    fetchChannelsFromWorker("https://evrtv.rahoumc07.workers.dev/api/db?endpoint=beINsd_channels", BeSdActivity.class);
                    break;
                case "ssc":
                    fetchChannelsFromWorker("https://evrtv.rahoumc07.workers.dev/api/db?endpoint=ssc_channels", SscActivity.class);
                    break;
                case "other":
                    fetchChannelsFromWorker("https://evrtv.rahoumc07.workers.dev/api/db?endpoint=other_channels", OtherActivity.class);
                    break;
            }
        }
    }

    private void fetchChannelsFromWorker(String workerUrl, Class<?> activityClass) {
        String timestamp = String.valueOf(System.currentTimeMillis() / 1000);
        String nonce = generateNonce();
        String path = workerUrl.substring(workerUrl.indexOf("/api"));
        String signature = generateHmacSignature(timestamp, nonce, path);
        
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(
            Request.Method.GET, workerUrl, null,
            new Response.Listener<JSONObject>() {
                @Override
                public void onResponse(JSONObject response) {
                    try {
                        Type type = new TypeToken<Map<String, String>>() {}.getType();
                        Map<String, String> channelMap = new Gson().fromJson(response.toString(), type);
                        List<String> channelList = new ArrayList<>(channelMap.values());
                        String[] keys = channelList.toArray(new String[0]);
                        Intent intent = new Intent(getContext(), activityClass);
                        for (String key : keys) {
                            if (grid1.containsKey(key)) {
                                intent.putExtra(key, String.valueOf(grid1.get(key)));
                            }
                        }
                        intent.putExtra("keys", keys);
                        startActivity(intent);
                    } catch (Exception e) {
                        Log.e("CloudflareError", "Parsing Error: " + e.getMessage());
                    }
                }
            },
            new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Log.e("CloudflareError", "Request Failed: " + error.getMessage());
                }
            }
        ) {
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> headers = new HashMap<>();
                headers.put("X-API-KEY", API_KEY);
                headers.put("X-TIMESTAMP", timestamp);
                headers.put("X-NONCE", nonce);
                headers.put("X-SIGNATURE", signature);
                return headers;
            }
        };
        requestQueue.add(jsonObjectRequest);
    }

    private String generateNonce() {
        byte[] nonce = new byte[16];
        new Random().nextBytes(nonce);
        return bytesToHex(nonce);
    }

    private String generateHmacSignature(String timestamp, String nonce, String path) {
        try {
            String dataToSign = timestamp + nonce + path;
            Mac sha256_HMAC = Mac.getInstance("HmacSHA256");
            SecretKeySpec secret_key = new SecretKeySpec(HMAC_SECRET.getBytes(), "HmacSHA256");
            sha256_HMAC.init(secret_key);
            byte[] hash = sha256_HMAC.doFinal(dataToSign.getBytes());
            return bytesToHex(hash);
        } catch (Exception e) {
            Log.e("HMAC", "Error generating signature", e);
            return "";
        }
    }

    private static String bytesToHex(byte[] bytes) {
        StringBuilder result = new StringBuilder();
        for (byte b : bytes) {
            result.append(String.format("%02x", b));
        }
        return result.toString();
    }

    public class Recyclerview1Adapter extends RecyclerView.Adapter<Recyclerview1Adapter.ViewHolder> {
        ArrayList<HashMap<String, Object>> _data;

        public Recyclerview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
            _data = _arr;
        }

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            LayoutInflater _inflater = getActivity().getLayoutInflater();
            View _v = _inflater.inflate(R.layout.home_cu, null);
            RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            _v.setLayoutParams(_lp);
            return new ViewHolder(_v);
        }

        @Override
        public void onBindViewHolder(ViewHolder _holder, final int _position) {
            View _view = _holder.itemView;
            final com.google.android.material.card.MaterialCardView cardview1 = _view.findViewById(R.id.cardview1);
            final LinearLayout linear3 = _view.findViewById(R.id.linear3);
            final TextView textview1 = _view.findViewById(R.id.textview1);

            cardview1.setVisibility(View.VISIBLE);
            textview1.setText(category_list.get((int) _position).get("key").toString());

            cardview1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View _view) {
                    switch (_position) {
                        case 0:
                            openCachedActivity("beINfhd", BeFhdActivity.class);
                            break;
                        case 1:
                            openCachedActivity("beINhd", BeHdActivity.class);
                            break;
                        case 2:
                            openCachedActivity("beINsd", BeSdActivity.class);
                            break;
                        case 3:
                            openCachedActivity("ssc", SscActivity.class);
                            break;
                        case 4:
                            openCachedActivity("other", OtherActivity.class);
                            break;
                    }
                }
            });
        }

        @Override
        public int getItemCount() {
            return _data.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {
            public ViewHolder(View v) {
                super(v);
            }
        }
    }
}