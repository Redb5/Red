package com.rtvapp.red;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.lang.reflect.Type;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

public class EventFragmentActivity extends Fragment {
    private RecyclerView recyclerView;
    private MatchesAdapter adapter;
    private List<Match> matches = new ArrayList<>();
    private Handler autoRefreshHandler;
    private static final long REFRESH_INTERVAL = 15000; // 15 ثانية
    
    // مفاتيح المصادقة
    private static final String HMAC_SECRET = "5ffc36387eaaf6a8ae23f2edc74683c619ac50c9d67654da0fcde0907a061167";
    private static final String API_KEY = "3a7d8f1e4c9b2a5d6e8f0a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1";

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.event_fragment, container, false);
        
        initializeViews(view);
        setupRecyclerView();
        
        if (isNetworkAvailable()) {
            loadMatches();
        }
        
        startAutoRefresh();
        
        return view;
    }

    private void initializeViews(View view) {
        recyclerView = view.findViewById(R.id.recyclerView);
    }

    private void setupRecyclerView() {
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new MatchesAdapter(getContext(), matches);
        recyclerView.setAdapter(adapter);
    }

    private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager = 
            (ConnectivityManager) getActivity().getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

    private void startAutoRefresh() {
        autoRefreshHandler = new Handler();
        autoRefreshHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (isNetworkAvailable()) {
                    loadMatches();
                }
                autoRefreshHandler.postDelayed(this, REFRESH_INTERVAL);
            }
        }, REFRESH_INTERVAL);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (autoRefreshHandler != null) {
            autoRefreshHandler.removeCallbacksAndMessages(null);
        }
    }

    private void loadMatches() {
        new FetchMatchesTask().execute("https://evrtv.rahoumc07.workers.dev/api/matches");
    }

    private class FetchMatchesTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... urls) {
            try {
                String timestamp = String.valueOf(System.currentTimeMillis() / 1000);
                String nonce = generateNonce();
                String path = extractPathFromUrl(urls[0]);
                String signature = generateHmacSignature(timestamp, nonce, path);
                
                URL url = new URL(urls[0]);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(15000);
                connection.setReadTimeout(15000);
                
                // إضافة رؤوس المصادقة
                connection.setRequestProperty("X-API-KEY", API_KEY);
                connection.setRequestProperty("X-TIMESTAMP", timestamp);
                connection.setRequestProperty("X-NONCE", nonce);
                connection.setRequestProperty("X-SIGNATURE", signature);

                int responseCode = connection.getResponseCode();
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                    String inputLine;
                    StringBuilder response = new StringBuilder();

                    while ((inputLine = in.readLine()) != null) {
                        response.append(inputLine);
                    }
                    in.close();
                    return response.toString();
                } else {
                    Log.e("FetchMatchesTask", "Server returned HTTP " + responseCode);
                }
            } catch (Exception e) {
                Log.e("FetchMatchesTask", "Error fetching matches", e);
            }
            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            if (result != null) {
                try {
                    Gson gson = new Gson();
                    Type listType = new TypeToken<List<Match>>(){}.getType();
                    List<Match> newMatches = gson.fromJson(result, listType);
                    
                    if (newMatches != null) {
                        adapter.updateMatches(newMatches);
                    }
                } catch (Exception e) {
                    Log.e("FetchMatchesTask", "Error parsing JSON", e);
                }
            }
        }
    }

    // ===== دوال المصادقة ===== //
    
    private String generateNonce() {
        byte[] nonce = new byte[16];
        new Random().nextBytes(nonce);
        return bytesToHex(nonce);
    }

    private String generateHmacSignature(String timestamp, String nonce, String path) {
        try {
            String dataToSign = timestamp + nonce + path;
            Mac sha256_HMAC = Mac.getInstance("HmacSHA256");
            SecretKeySpec secret_key = new SecretKeySpec(HMAC_SECRET.getBytes(), "HmacSHA256");
            sha256_HMAC.init(secret_key);
            byte[] hash = sha256_HMAC.doFinal(dataToSign.getBytes());
            return bytesToHex(hash);
        } catch (Exception e) {
            Log.e("HMAC", "Error generating signature", e);
            return "";
        }
    }

    private static String bytesToHex(byte[] bytes) {
        StringBuilder result = new StringBuilder();
        for (byte b : bytes) {
            result.append(String.format("%02x", b));
        }
        return result.toString();
    }

    private String extractPathFromUrl(String urlString) {
        try {
            URL url = new URL(urlString);
            String path = url.getPath();
            String query = url.getQuery();
            return query != null ? path + "?" + query : path;
        } catch (Exception e) {
            Log.e("URL", "Error extracting path from URL", e);
            return "/api/matches"; // مسار افتراضي في حالة الخطأ
        }
    }
}