package com.rtvapp.red;

import android.annotation.SuppressLint;
import android.app.PictureInPictureParams;
import android.content.Context;
import android.content.res.Configuration;
import android.media.AudioManager;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkRequest;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Rational;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.FirebaseApp;

import androidx.media3.common.C;
import androidx.media3.common.MediaItem;
import androidx.media3.common.Player;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Tracks;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.LoadControl;
import androidx.media3.exoplayer.DefaultLoadControl;
import androidx.media3.exoplayer.DefaultRenderersFactory;
import androidx.media3.exoplayer.source.MediaSource;
import androidx.media3.exoplayer.source.ProgressiveMediaSource;
import androidx.media3.exoplayer.upstream.DefaultBandwidthMeter;
import androidx.media3.exoplayer.upstream.DefaultAllocator;
import androidx.media3.ui.PlayerView;

public class PlayerActivity extends AppCompatActivity {

    private ExoPlayer exoPlayer;
    private PlayerView playerView;
    private ImageView pauseButton;
    private ProgressBar progressBar;
    private long currentPosition = 0;
    private boolean isPlaying = true;

    private AudioManager audioManager;
    private float currentBrightness;
    private Window window;
    private GestureDetector gestureDetector;
    private ConnectivityManager.NetworkCallback networkCallback;

    // تعريف الـ Listener كمتغير عضو في الكلاس
    private final Player.Listener playerListener = new Player.Listener() {
        @Override
        public void onPlaybackStateChanged(int state) {
            if (exoPlayer == null) return;

            if (state == Player.STATE_ENDED) {
                handlePlaybackEnded();
            }

            if (state == Player.STATE_BUFFERING) {
                progressBar.setVisibility(View.VISIBLE);
            } else if (state == Player.STATE_READY) {
                progressBar.setVisibility(View.GONE);
            }
        }

        @Override
        public void onPlayerError(@NonNull PlaybackException exception) {
            if (isNetworkError(exception)) {
                // إعادة المحاولة بعد تأخير
                showToast("مشكلة في الاتصال، جاري إعادة المحاولة...");
                new Handler(Looper.getMainLooper()).postDelayed(() -> {
                    if (exoPlayer != null) {
                        exoPlayer.prepare();
                        exoPlayer.setPlayWhenReady(true);
                    }
                }, 2000); // إعادة المحاولة بعد ثانيتين
            } else {
                handlePlayerError(exception);
            }
        }

        @Override
        public void onTracksChanged(@NonNull Tracks tracks) {
            // عرض خيارات الجودة إذا كانت متاحة
            if (tracks.getGroups().size() > 1) {
                showQualitySelector(tracks);
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.player);
        FirebaseApp.initializeApp(this);

        setupFullScreen();
        initializeViews();
        initializePlayer(savedInstanceState);
        setupControls();
        setupGestureDetector();
        setupNetworkMonitor();
    }

    private void setupFullScreen() {
        window = getWindow();
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            window.getAttributes().layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.setDecorFitsSystemWindows(false);
            WindowInsetsController controller = window.getInsetsController();
            if (controller != null) {
                controller.hide(WindowInsets.Type.systemBars());
                controller.setSystemBarsBehavior(
                        WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            int flags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
            window.getDecorView().setSystemUiVisibility(flags);
        }
    }

    private void initializeViews() {
        playerView = findViewById(R.id.playerView);
        pauseButton = playerView.findViewById(R.id.pause);
        progressBar = findViewById(R.id.progressBar);
        audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);

        // إظهار الأزرار بشكل دائم
        pauseButton.setVisibility(View.VISIBLE);
        playerView.findViewById(R.id.back_arrow).setVisibility(View.VISIBLE);
        playerView.findViewById(R.id.replay_10).setVisibility(View.VISIBLE);
        playerView.findViewById(R.id.forward_10).setVisibility(View.VISIBLE);
    }

    private void initializePlayer(Bundle savedInstanceState) {
        // إنشاء LoadControl محسن للتخزين المؤقت
        LoadControl loadControl = new DefaultLoadControl.Builder()
                .setAllocator(new DefaultAllocator(true, C.DEFAULT_BUFFER_SEGMENT_SIZE))
                .setBufferDurationsMs(
                        5000,  // الحد الأدنى للتخزين المؤقت
                        30000, // الحد الأقصى للتخزين المؤقت
                        2000,  // التخزين المؤقت للبدء
                        5000   // التخزين المؤقت بعد التوقف
                )
                .setPrioritizeTimeOverSizeThresholds(true)
                .build();

        // إنشاء ExoPlayer مع إعدادات محسنة
        exoPlayer = new ExoPlayer.Builder(this)
                .setLoadControl(loadControl)
                .setRenderersFactory(new DefaultRenderersFactory(this)
                        .setEnableDecoderFallback(true))
                .build();

        playerView.setPlayer(exoPlayer);

        // إضافة الـ Listener
        exoPlayer.addListener(playerListener);

        if (savedInstanceState != null) {
            currentPosition = savedInstanceState.getLong("position", 0);
            isPlaying = savedInstanceState.getBoolean("isPlaying", true);
        }

        String videoUrl = getIntent().getStringExtra("data");
        if (videoUrl != null && !videoUrl.isEmpty()) {
            MediaItem mediaItem = MediaItem.fromUri(Uri.parse(videoUrl));
            exoPlayer.setMediaItem(mediaItem);
            exoPlayer.prepare();
            exoPlayer.seekTo(currentPosition);
            exoPlayer.setPlayWhenReady(isPlaying);
        } else {
            showToast("رابط الفيديو غير صالح");
            finish();
        }
    }

    private void setupControls() {
        ImageView backArrow = playerView.findViewById(R.id.back_arrow);
        ImageView pipButton = playerView.findViewById(R.id.pip_button);
        ImageView replay10 = playerView.findViewById(R.id.replay_10);
        ImageView forward10 = playerView.findViewById(R.id.forward_10);

        backArrow.setOnClickListener(v -> finish());
        pipButton.setOnClickListener(v -> togglePipMode());
        pauseButton.setOnClickListener(v -> togglePlayPause());
        replay10.setOnClickListener(v -> seekBy(-10_000));
        forward10.setOnClickListener(v -> seekBy(10_000));
    }

    private void setupGestureDetector() {
        gestureDetector = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
                float deltaY = e2.getY() - e1.getY();
                if (e1.getX() < playerView.getWidth() / 2) {
                    adjustVolume(deltaY);
                } else {
                    adjustBrightness(deltaY);
                }
                return true;
            }
        });

        playerView.setOnTouchListener((v, event) -> {
            gestureDetector.onTouchEvent(event);
            return false; // السماح بتمرير الأحداث للأزرار
        });
    }

    private void setupNetworkMonitor() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkRequest.Builder builder = new NetworkRequest.Builder();
        
        networkCallback = new ConnectivityManager.NetworkCallback() {
            @Override
            public void onAvailable(@NonNull Network network) {
                runOnUiThread(() -> showToast("الاتصال متاح"));
            }

            @Override
            public void onLost(@NonNull Network network) {
                runOnUiThread(() -> showToast("فقدان الاتصال"));
            }

            @Override
            public void onUnavailable() {
                runOnUiThread(() -> showToast("الاتصال غير متاح"));
            }
        };

        connectivityManager.registerNetworkCallback(builder.build(), networkCallback);
    }

    private void showQualitySelector(Tracks tracks) {
        // هنا يمكنك تنفيذ واجهة لاختيار الجودة
        // مثال مبسط باستخدام AlertDialog
        /*
        new AlertDialog.Builder(this)
                .setTitle("اختر جودة التشغيل")
                .setItems(qualityOptions, (dialog, which) -> {
                    // تغيير الجودة حسب الاختيار
                })
                .show();
        */
    }

    private boolean isNetworkError(PlaybackException exception) {
    return exception.errorCode == PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED ||
           exception.errorCode == PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT ||
           exception.errorCode == PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS ||
           exception.errorCode == PlaybackException.ERROR_CODE_IO_FILE_NOT_FOUND;
    }

    private void adjustVolume(float deltaY) {
        int maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        int currentVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
        int newVolume = (int) (currentVolume - (deltaY / playerView.getHeight()) * maxVolume);
        newVolume = Math.max(0, Math.min(newVolume, maxVolume));
        audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, newVolume, 0);
    }

    private void adjustBrightness(float deltaY) {
        float newBrightness = currentBrightness - (deltaY / playerView.getHeight());
        newBrightness = Math.max(0, Math.min(newBrightness, 1));
        WindowManager.LayoutParams layoutParams = window.getAttributes();
        layoutParams.screenBrightness = newBrightness;
        window.setAttributes(layoutParams);
        currentBrightness = newBrightness;
    }

    private void togglePlayPause() {
        if (exoPlayer != null) {
            isPlaying = !exoPlayer.getPlayWhenReady();
            exoPlayer.setPlayWhenReady(isPlaying);
            updatePlayPauseIcon();
        }
    }

    private void updatePlayPauseIcon() {
        pauseButton.setImageResource(isPlaying ? R.drawable.pause : R.drawable.play);
    }

    private void seekBy(long milliseconds) {
        if (exoPlayer != null) {
            long newPosition = exoPlayer.getCurrentPosition() + milliseconds;
            newPosition = Math.max(0, Math.min(newPosition, exoPlayer.getDuration()));
            exoPlayer.seekTo(newPosition);
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    private void togglePipMode() {
        if (!isInPictureInPictureMode()) {
            Rational aspectRatio = new Rational(16, 9);
            PictureInPictureParams params = new PictureInPictureParams.Builder()
                    .setAspectRatio(aspectRatio)
                    .build();
            enterPictureInPictureMode(params);
        }
    }

    @Override
    public void onPictureInPictureModeChanged(boolean isInPiP, Configuration newConfig) {
        super.onPictureInPictureModeChanged(isInPiP, newConfig);
        playerView.setUseController(!isInPiP);
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        if (exoPlayer != null) {
            outState.putLong("position", exoPlayer.getCurrentPosition());
            outState.putBoolean("isPlaying", exoPlayer.getPlayWhenReady());
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (exoPlayer != null) {
            // لا تتوقف عن التشغيل إذا كان في وضع PiP
            if (!(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && isInPictureInPictureMode())) {
                currentPosition = exoPlayer.getCurrentPosition();
                isPlaying = false;
                exoPlayer.setPlayWhenReady(false);
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (exoPlayer != null) {
            exoPlayer.setPlayWhenReady(isPlaying);
            exoPlayer.seekTo(currentPosition);
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (exoPlayer != null) {
            currentPosition = exoPlayer.getCurrentPosition();
            isPlaying = exoPlayer.getPlayWhenReady();
            exoPlayer.stop();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // إلغاء تسجيل مراقبة الشبكة
        if (networkCallback != null) {
            ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            connectivityManager.unregisterNetworkCallback(networkCallback);
        }
        releasePlayer();
    }

    private void releasePlayer() {
        if (exoPlayer != null) {
            exoPlayer.removeListener(playerListener);
            exoPlayer.release();
            exoPlayer = null;
        }
    }

    private void handlePlaybackEnded() {
        if (exoPlayer != null) {
            exoPlayer.seekTo(0);
            exoPlayer.setPlayWhenReady(true);
        }
    }

    private void handlePlayerError(PlaybackException exception) {
        showToast("حدث خطأ في التشغيل: " + exception.getMessage());
        finish();
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onBackPressed() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && isInPictureInPictureMode()) {
            finish();
        } else {
            super.onBackPressed();
        }
    }
}