package com.rtvapp.red;

import android.animation.*;
import android.app.*;
import android.app.AlertDialog;
import android.content.*;
import android.content.DialogInterface;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.LinearLayout;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.*;
import androidx.customview.*;
import androidx.customview.poolingcontainer.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.media.*;
import androidx.media3.exoplayer.*;
import androidx.media3.exoplayer.dash.*;
import androidx.media3.ui.*;
import androidx.recyclerview.*;
import com.android.volley.*;
import com.bumptech.glide.*;
import com.google.android.material.appbar.AppBarLayout;
import com.google.firebase.FirebaseApp;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;

public class OtherActivity extends AppCompatActivity {

    private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();

    private Toolbar _toolbar;
    private AppBarLayout _app_bar;
    private CoordinatorLayout _coordinator;
    private HashMap<String, Object> grid1 = new HashMap<>();
    private String chain1 = "";

    private ArrayList<HashMap<String, Object>> channels_list = new ArrayList<>();

    private LinearLayout linear1;
    private GridView gridview1;
    private LinearLayout linear2;

    private AlertDialog.Builder no_internet;
    private RequestNetwork wifi;
    private RequestNetwork.RequestListener _wifi_request_listener;
    private DatabaseReference Db = _firebase.getReference("Db");
    private ChildEventListener _Db_child_listener;

    @Override
    protected void onCreate(Bundle _savedInstanceState) {
        super.onCreate(_savedInstanceState);
        setContentView(R.layout.other);
        initialize(_savedInstanceState);
        FirebaseApp.initializeApp(this);
        initializeLogic();
    }

    private void initialize(Bundle _savedInstanceState) {
        _app_bar = findViewById(R.id._app_bar);
        _coordinator = findViewById(R.id._coordinator);
        _toolbar = findViewById(R.id._toolbar);
        setSupportActionBar(_toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        _toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View _v) {
                onBackPressed();
            }
        });
        linear1 = findViewById(R.id.linear1);
        gridview1 = findViewById(R.id.gridview1);
        linear2 = findViewById(R.id.linear2);

        no_internet = new AlertDialog.Builder(this);
        wifi = new RequestNetwork(this);

        gridview1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> _param1, View _param2, int _position, long _param4) {
                String channelName = ((Gridview1Adapter) gridview1.getAdapter()).getItem(_position).get("key").toString();
                if (grid1.containsKey(channelName)) {
                    String chain1 = grid1.get(channelName).toString();
                    startActivity(new Intent(getApplicationContext(), PlayerActivity.class)
                        .putExtra("mode", true)
                        .putExtra("data", chain1));
                } else {
                    System.out.println("القيمة فارغة أو غير موجودة للقناة: " + channelName);
                }
            }
        });

        _wifi_request_listener = new RequestNetwork.RequestListener() {
            @Override
            public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
                final String _tag = _param1;
                final String _response = _param2;
                final HashMap<String, Object> _responseHeaders = _param3;
            }

            @Override
            public void onErrorResponse(String _param1, String _param2) {
                final String _tag = _param1;
                final String _message = _param2;
                no_internet.setTitle("Connection Error\n");
                no_internet.setMessage("You are not connected to the internet. Please check your connection and try again.");
                no_internet.setIcon(R.drawable.no_internet);
                no_internet.setPositiveButton("Reload", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface _dialog, int _which) {
                        finish();
                        startActivity(getIntent());
                    }
                });
                no_internet.setCancelable(false);
                no_internet.create().show();
            }
        };

        _Db_child_listener = new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot _param1, String _param2) {
                GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
                final String _childKey = _param1.getKey();
                final HashMap<String, Object> _childValue = _param1.getValue(_ind);
            }

            @Override
            public void onChildChanged(DataSnapshot _param1, String _param2) {
                GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
                final String _childKey = _param1.getKey();
                final HashMap<String, Object> _childValue = _param1.getValue(_ind);
            }

            @Override
            public void onChildMoved(DataSnapshot _param1, String _param2) {}

            @Override
            public void onChildRemoved(DataSnapshot _param1) {
                GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
                final String _childKey = _param1.getKey();
                final HashMap<String, Object> _childValue = _param1.getValue(_ind);
            }

            @Override
            public void onCancelled(DatabaseError _param1) {
                final int _errorCode = _param1.getCode();
                final String _errorMessage = _param1.getMessage();
            }
        };
        Db.addChildEventListener(_Db_child_listener);
    }

    private void initializeLogic() {
        _navigationBarColor();
        gridview1.setSelector(android.R.color.transparent);
        _getValue();
        _addChannelToList();
        _hideVerticalScrollBarGrid();
        gridview1.setAdapter(new Gridview1Adapter(channels_list));
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuItem menuItem = menu.add(Menu.NONE, 0, Menu.NONE, "search");
        menuItem.setIcon(R.drawable.ic_search);
        menuItem.setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        final int _id = item.getItemId();
        final String _title = (String) item.getTitle();
        if (item.getItemId() == 0) { // التحقق من معرف العنصر (0 هو المعرف الذي استخدمته في menu.add)
            // إنشاء SearchView
            SearchView searchView = new SearchView(this);
            searchView.setQueryHint("ابحث هنا..."); // نص تلميح البحث
            searchView.setIconifiedByDefault(false); // توسيع SearchView تلقائيًا

            // الوصول إلى EditText داخل SearchView
            EditText searchEditText = searchView.findViewById(androidx.appcompat.R.id.search_src_text);
            if (searchEditText != null) {
                // تغيير لون النص التلميحي (hint) إلى الأبيض
                searchEditText.setHintTextColor(Color.WHITE);

                // تغيير لون النص المكتوب (textColor) إلى الأبيض
                searchEditText.setTextColor(Color.WHITE);
            }

            // Listener لاستعلام البحث
            searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
                @Override
                public boolean onQueryTextSubmit(String query) {
                    // تنفيذ الإجراء عند إرسال البحث
                    Toast.makeText(OtherActivity.this, "بحث عن: " + query, Toast.LENGTH_SHORT).show();
                    return true;
                }

                @Override
                public boolean onQueryTextChange(String newText) {
                    // تنفيذ الإجراء عند تغيير نص البحث (اختياري)
                    ((Gridview1Adapter) gridview1.getAdapter()).getFilter().filter(newText);
                    return false;
                }
            });

            // تعيين SearchView كإجراء لعنصر القائمة
            item.setActionView(searchView);
            item.expandActionView(); // توسيع SearchView تلقائيًا
        }
        return super.onOptionsItemSelected(item);
    }

    public void _hideVerticalScrollBarGrid() {
        GridView gridView = findViewById(R.id.gridview1);
        gridView.setVerticalScrollBarEnabled(false);
        gridView.setHorizontalScrollBarEnabled(false);
    }

    public void _navigationBarColor() {
        getWindow().setNavigationBarColor(Color.parseColor("#5580A0"));
    }

    public void _addChannelToList() {
        String[] keys = getIntent().getStringArrayExtra("keys"); // استقبال مصفوفة keys
        if (keys != null) {
            for (String channel : keys) {
                HashMap<String, Object> _item = new HashMap<>();
                _item.put("key", channel);
                channels_list.add(_item);
            }
        }
    }

    public void _getValue() {
        grid1 = new HashMap<>();
        Db.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot _dataSnapshot) {
                if (_dataSnapshot.child("chain").exists()) {
                    for (DataSnapshot tvData : _dataSnapshot.child("chain").getChildren()) {
                        String key = tvData.getKey();
                        Object value = tvData.getValue();
                        grid1.put(key, value);
                    }
                }
                grid1.put("test", "test");
            }

            @Override
            public void onCancelled(DatabaseError _databaseError) {}
        });
    }

    public class Gridview1Adapter extends BaseAdapter implements Filterable {
        ArrayList<HashMap<String, Object>> _originalList;
        ArrayList<HashMap<String, Object>> _filteredList;

        public Gridview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
            _originalList = new ArrayList<>(_arr);
            _filteredList = new ArrayList<>(_arr);
        }

        @Override
        public int getCount() {
            return _filteredList.size();
        }

        @Override
        public HashMap<String, Object> getItem(int _index) {
            return _filteredList.get(_index);
        }

        @Override
        public long getItemId(int _index) {
            return _index;
        }

        @Override
        public View getView(final int _position, View _v, ViewGroup _container) {
            LayoutInflater _inflater = getLayoutInflater();
            View _view = _v;
            if (_view == null) {
                _view = _inflater.inflate(R.layout.grid_cu, null);
            }

            final androidx.cardview.widget.CardView cardview1 = _view.findViewById(R.id.cardview1);
            final LinearLayout linear3 = _view.findViewById(R.id.linear3);
            final ImageView imageview1 = _view.findViewById(R.id.imageview1);
            final TextView textview1 = _view.findViewById(R.id.textview1);

            textview1.setText(_filteredList.get(_position).get("key").toString());

            String channelName = _filteredList.get(_position).get("key").toString();
            String imageUrl = getIntent().getStringExtra(channelName);

            if (imageUrl != null && !imageUrl.isEmpty()) {
                Glide.with(getApplicationContext())
                     .load(imageUrl)
                     .placeholder(R.drawable.loading)
                     .error(R.drawable.placehold)
                     .into(imageview1);
            } else {
                imageview1.setImageResource(R.drawable.placehold);
            }

            textview1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/opensans_bold.ttf"), 0);

            return _view;
        }

        @Override
        public Filter getFilter() {
            return new Filter() {
                @Override
                protected FilterResults performFiltering(CharSequence constraint) {
                    FilterResults results = new FilterResults();
                    ArrayList<HashMap<String, Object>> filteredList = new ArrayList<>();

                    if (constraint == null || constraint.length() == 0) {
                        filteredList.addAll(_originalList);
                    } else {
                        String filterPattern = constraint.toString().toLowerCase().trim();

                        for (HashMap<String, Object> item : _originalList) {
                            if (item.get("key").toString().toLowerCase().contains(filterPattern)) {
                                filteredList.add(item);
                            }
                        }
                    }

                    results.values = filteredList;
                    results.count = filteredList.size();
                    return results;
                }

                @Override
                protected void publishResults(CharSequence constraint, FilterResults results) {
                    _filteredList.clear();
                    _filteredList.addAll((ArrayList<HashMap<String, Object>>) results.values);
                    notifyDataSetChanged();
                }
            };
        }
    }
}