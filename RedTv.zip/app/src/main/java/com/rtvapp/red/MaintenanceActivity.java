package com.rtvapp.red;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MaintenanceActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.maintenance);

        // تهيئة زر إعادة المحاولة
        Button btnRetry = findViewById(R.id.btn_retry);
        btnRetry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // إعادة تشغيل التطبيق
                Intent intent = new Intent(MaintenanceActivity.this, MainActivity.class);
                startActivity(intent);
                finish(); // إغلاق النشاط الحالي
            }
        });
    }
}