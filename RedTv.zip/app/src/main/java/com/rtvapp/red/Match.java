package com.rtvapp.red;

import com.google.gson.annotations.SerializedName;
import java.util.List;

public class Match {
    @SerializedName("league")
    private String league;
    
    @SerializedName("match_name")
    private String matchName;
    
    @SerializedName("home_logo")
    private String homeLogo;
    
    @SerializedName("away_logo")
    private String awayLogo;
    
    @SerializedName("match_time")
    private String matchTime;
    
    @SerializedName("score")
    private String score;
    
    @SerializedName("status")
    private String status;
    
    @SerializedName("channels")
    private String channels;
    
    @SerializedName("home_team")
    private String homeTeam;
    
    @SerializedName("away_team")
    private String awayTeam;
    
    @SerializedName("home_scorers")
    private List<String> homeScorers;
    
    @SerializedName("away_scorers")
    private List<String> awayScorers;

    // Getters
    public String getLeague() {
        return league;
    }

    public String getMatchName() {
        return matchName;
    }

    public String getHomeLogo() {
        return homeLogo;
    }

    public String getAwayLogo() {
        return awayLogo;
    }

    public String getMatchTime() {
        return matchTime;
    }

    public String getScore() {
        return score;
    }

    public String getStatus() {
        return status;
    }

    public String getChannels() {
        return channels;
    }

    public String getHomeTeam() {
        if (homeTeam != null && !homeTeam.isEmpty()) {
            return homeTeam;
        }
        
        // Fallback to extracting from match_name if homeTeam is not available
        if (matchName == null) return "";
        
        String[] separators = {" vs ", " Vs ", " VS ", "-", " – "};
        for (String separator : separators) {
            if (matchName.contains(separator)) {
                String[] parts = matchName.split(separator);
                if (parts.length > 0) {
                    return parts[0].trim();
                }
            }
        }
        return matchName;
    }

    public String getAwayTeam() {
        if (awayTeam != null && !awayTeam.isEmpty()) {
            return awayTeam;
        }
        
        // Fallback to extracting from match_name if awayTeam is not available
        if (matchName == null) return "";
        
        String[] separators = {" vs ", " Vs ", " VS ", "-", " – "};
        for (String separator : separators) {
            if (matchName.contains(separator)) {
                String[] parts = matchName.split(separator);
                if (parts.length > 1) {
                    return parts[1].trim();
                }
            }
        }
        return "";
    }

    public List<String> getHomeScorers() {
        return homeScorers;
    }

    public List<String> getAwayScorers() {
        return awayScorers;
    }
    
    public String getFormattedHomeScorers() {
        if (homeScorers == null || homeScorers.isEmpty()) {
            return "No scorers";
        }
        return String.join("\n", homeScorers);
    }
    
    public String getFormattedAwayScorers() {
        if (awayScorers == null || awayScorers.isEmpty()) {
            return "No scorers";
        }
        return String.join("\n", awayScorers);
    }
}