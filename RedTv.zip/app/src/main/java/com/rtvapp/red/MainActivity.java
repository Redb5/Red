package com.rtvapp.red;

import android.os.Looper;
import android.os.Handler;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.ProxyInfo;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;
import androidx.viewpager.widget.ViewPager;
import com.google.android.material.tabs.TabLayout;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {

    private boolean doubleBackToExitPressedOnce = false;
    private DatabaseReference dbRef;
    private ChildEventListener dbChildListener;
    private FrFragmentAdapter frFragmentAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        checkAppStatus(); // التحقق من وضع الصيانة
        initializeViews(); // تهيئة العناصر الرئيسيّة
        initializeFirebase(); // تهيئة Firebase
        initializeLogic(); // تشغيل المنطق الأساسي
    }

    /**
     * التحقق من وضع الصيانة.
     */
    private void checkAppStatus() {
        DatabaseReference statusRef = FirebaseDatabase.getInstance().getReference("Db/app_status/status");
        statusRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    String status = snapshot.getValue(String.class);
                    if (status != null && status.equals("inactive")) {
                        startActivity(new Intent(MainActivity.this, MaintenanceActivity.class));
                        finish();
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                showToast("Failed to check app status");
                Log.e("MainActivity", "Database error: " + error.getMessage());
            }
        });
    }

    /**
     * تهيئة العناصر الرئيسيّة مثل Toolbar و ViewPager.
     */
    private void initializeViews() {
        Toolbar toolbar = findViewById(R.id._toolbar);
        setSupportActionBar(toolbar);

        ViewPager viewPager = findViewById(R.id.viewpager1);
        TabLayout tabLayout = findViewById(R.id.tablayout2);

        frFragmentAdapter = new FrFragmentAdapter(getSupportFragmentManager());
        viewPager.setAdapter(frFragmentAdapter);
        tabLayout.setupWithViewPager(viewPager);
    }

    /**
     * تهيئة Firebase.
     */
    private void initializeFirebase() {
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        dbRef = database.getReference("Db");
        dbChildListener = new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot snapshot, String previousChildName) {}

            @Override
            public void onChildChanged(@NonNull DataSnapshot snapshot, String previousChildName) {}

            @Override
            public void onChildRemoved(@NonNull DataSnapshot snapshot) {}

            @Override
            public void onChildMoved(@NonNull DataSnapshot snapshot, String previousChildName) {}

            @Override
            public void onCancelled(@NonNull DatabaseError error) {}
        };
        dbRef.addChildEventListener(dbChildListener);
    }

    /**
     * تشغيل المنطق الأساسي للتطبيق.
     */
    private void initializeLogic() {
        checkForUpdates(); // التحقق من وجود تحديثات
        checkForProxy(); // التحقق من وجود Proxy
        checkForDangerousApps(); // التحقق من التطبيقات الخطرة
    }

    /**
     * التحقق من وجود تحديثات.
     */
    private void checkForUpdates() {
        dbRef.child("update").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    String latestVersion = snapshot.child("version").getValue(String.class);
                    String currentVersion = getCurrentVersion();
                    if (!latestVersion.equals(currentVersion)) {
                        showUpdateDialog(
                            snapshot.child("message").getValue(String.class),
                            snapshot.child("url").getValue(String.class)
                        );
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e("MainActivity", "Update check failed: " + error.getMessage());
            }
        });
    }

    /**
     * الحصول على الإصدار الحالي للتطبيق.
     */
    private String getCurrentVersion() {
        try {
            PackageInfo pInfo = getPackageManager().getPackageInfo(getPackageName(), 0);
            return pInfo.versionName;
        } catch (PackageManager.NameNotFoundException e) {
            return "1.0";
        }
    }

    /**
     * عرض حوار لتحديث التطبيق.
     */
    private void showUpdateDialog(String message, String url) {
        new AlertDialog.Builder(this)
            .setTitle("New Update Available")
            .setMessage(message)
            .setPositiveButton("Update Now", (dialog, which) -> openLinkInBrowser(url))
            .setNegativeButton("Later", (dialog, which) -> dialog.dismiss())
            .setCancelable(false)
            .show();
    }

    /**
     * فتح الرابط في متصفح خارجي.
     */
    private void openLinkInBrowser(String url) {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            startActivity(intent);
        } catch (Exception e) {
            showToast("Failed to open link in browser.");
            Log.e("MainActivity", "Error opening link: " + e.getMessage());
        }
    }

    /**
     * التحقق من وجود Proxy.
     */
    private void checkForProxy() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        if (cm != null) {
            ProxyInfo proxyInfo = cm.getDefaultProxy();
            if (proxyInfo != null) {
                showToast("Proxy detected!");
                finish();
            }
        }
    }

    /**
     * التحقق من التطبيقات الخطرة.
     */
    private void checkForDangerousApps() {
        String[] dangerousApps = {
            "com.charlesproxy", "app.greyshirts.sslcapture", "httptoolkit",
            "com.telerik.fiddler", "org.wireshark.android", "com.mwr.dz",
            "com.minhui.networkcapture", "org.sandroproxy.drony"
        };

        PackageManager pm = getPackageManager();
        for (String pkg : dangerousApps) {
            try {
                pm.getPackageInfo(pkg, 0);
                showToast("Dangerous app detected!");
                finish();
                break;
            } catch (PackageManager.NameNotFoundException ignored) {}
        }
    }

    /**
     * التعامل مع زر العودة.
     */
    @Override
    public void onBackPressed() {
        if (doubleBackToExitPressedOnce) {
            super.onBackPressed();
            return;
        }

        doubleBackToExitPressedOnce = true;
        showToast("Press back again to exit");

        new Handler(getMainLooper()).postDelayed(() -> doubleBackToExitPressedOnce = false, 2000);
    }

    /**
     * إظهار رسالة باستخدام Toast.
     */
    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    /**
     * تهيئة Pager Adapter للصفحات.
     */
    private static class FrFragmentAdapter extends FragmentStatePagerAdapter {
        FrFragmentAdapter(FragmentManager fm) { super(fm); }

        @NonNull
        @Override
        public Fragment getItem(int position) {
            return position == 0 ? new HomeFragmentActivity() : new EventFragmentActivity();
        }

        @Override
        public int getCount() { return 2; }

        @Override
        public CharSequence getPageTitle(int position) {
            return position == 0 ? "Home" : "Events";
        }
    }
}